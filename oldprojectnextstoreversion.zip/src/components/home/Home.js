import React from "react";
import Navbar from "../navbar/Navbar";
import Filter from "../filter/Filter";
import ProductList from "../Products/ProductList";
import "./Home.css";
const Home = () => {
  return (
    <div>
      <Navbar />
      <div className="flex">
        <div>
          <Filter />
        </div>
        <div>
          <ProductList />
        </div>
      </div>
    </div>
  );
};

export default Home;
