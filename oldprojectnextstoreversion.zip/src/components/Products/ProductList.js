import axios from "axios";
import React, { useEffect, useState } from "react";
import "./ProductList.css";

const ProductList = () => {
  const [prodlist, setProlist] = useState([]);

  useEffect(() => {
    axios.get("http://127.0.0.1:5000/getproducts").then((response) => {
      // console.log(response);
      const mydata = response.data;
      console.log("mydata", mydata);
      setProlist(mydata.Products);
    });
  }, []);

  return (
    <div className="row">
      {prodlist?.map((list) => {
        return (
          <>
            <div className="col-md-4">
              <img src={list.img} alt="" className="img-fluid" />
              <div>
                <p>{list.title}</p>
                <p>Category :{list.category}</p>
                <p>Price :{list.price}</p>
              </div>
            </div>
          </>
        );
      })}
    </div>
  );
};

export default ProductList;
