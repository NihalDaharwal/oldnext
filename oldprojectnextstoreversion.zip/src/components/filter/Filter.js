import React from "react";
import FilterCatogory from "./FilterCatogory.js";
import FilterPrice from "./FilterPrice.js";

const Filter = () => {
  return (
    <div>
      <input type="search" name="" id="" />
      <FilterCatogory />
      <FilterPrice />
      <button>Search</button>
    </div>
  );
};

export default Filter;
