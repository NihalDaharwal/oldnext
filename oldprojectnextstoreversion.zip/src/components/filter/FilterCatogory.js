import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import axios from "axios";

const FilterCatogory = () => {
  const [category, SetCategory] = useState([]);

  
  useEffect(() => {
    axios.get("http://127.0.0.1:5000/getproducts").then((response) => {
      // console.log(response);
      const categorydata = response.data;
      console.log("categorydata", categorydata);
      SetCategory(categorydata.Products);
      console.log(category);
    });
  }, []);

  return (
    <div>
      <div>
        <h6>Category</h6>
        <label htmlFor="electronics">
          {" "}
          <input type="checkbox" name="Electronics" id="" />
          Electronics
        </label>
      </div>
      <div>
        <label htmlFor="home&kitchen">
          <input type="checkbox" name="home&kitchen" id="" />
          Home & kitchen
        </label>

        <div>
          <label htmlFor="books">
            {" "}
            <input type="checkbox" name="books" id="" />
            Books
          </label>
        </div>
        <div>
          <label htmlFor="fashion">
            {" "}
            <input type="checkbox" name="fashion" id="" />
            Fashion
          </label>
        </div>
        <div>
          <label htmlFor="food">
            {" "}
            <input type="checkbox" name="food" id="" />
            Food
          </label>
        </div>
      </div>
    </div>
  );
};

export default FilterCatogory;
