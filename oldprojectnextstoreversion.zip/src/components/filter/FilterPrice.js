import React from "react";

const FilterPrice = () => {
  return (
    <div>
      <h6>Price Range</h6>
      
    </div>
  );
};

export default FilterPrice;
