import { CATEGORY_FILTER } from "../../actionTypes/Actiontypes";

export const CategoryFilter = () => {
  return {
    type: CATEGORY_FILTER,
    payload: "",
  };
};
