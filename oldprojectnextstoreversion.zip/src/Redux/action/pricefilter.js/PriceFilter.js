import { PRICE_FILTER } from "../../actionTypes/Actiontypes";

export const PriceFilter = () => {
  return {
    type: PRICE_FILTER,
    payload: "",
  };
};
