import { PRICE_FILTER } from "../actionTypes/Actiontypes";

const initialState = { products: [] };

const priceReducer = (state = initialState, action) => {
  switch (action.type) {
    case PRICE_FILTER:
      return {
        ...state,
      };

    default:
      return state;
  }
};
export default priceReducer;
