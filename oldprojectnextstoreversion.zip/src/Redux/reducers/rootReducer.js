import { combineReducers } from "redux";
import categoryReducer from "./categoryReducer";
import priceReducer from "./priceReducer";

const rootReducer = combineReducers({
  category: categoryReducer,
  price: priceReducer,
});

export default rootReducer;
