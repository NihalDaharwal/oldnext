import { CATEGORY_FILTER } from "../actionTypes/Actiontypes";

const initialState = {
  products: [],
};

const categoryReducer = (state = initialState, action) => {
  switch (action.type) {
    case CATEGORY_FILTER:
      return {
        ...state,
      };

    default:
      return state;
  }
};
export default categoryReducer;
